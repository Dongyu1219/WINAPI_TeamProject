#pragma once
#include <windows.h>

void DrawGrassMap(HDC mDC, HBITMAP hbitmapMap0);
void DrawWaterMap(HDC mDC, HBITMAP hbitmapMap0);
void DrawFireMap(HDC mDC, HBITMAP hbitmapMap0);
void DrawUpgradeMenu(HDC mDC, HINSTANCE g_hInst);